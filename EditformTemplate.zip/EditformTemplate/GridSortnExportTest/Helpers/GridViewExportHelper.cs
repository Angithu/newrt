﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DevExpress.Web.Mvc;
using DevExpress.XtraPrinting;

public enum GridViewExportFormat { None, Pdf, Xls, Xlsx, Rtf, Csv }
public delegate ActionResult GridViewExportMethod(GridViewSettings settings, object dataObject);

public class GridViewExportHelper
{
    static Dictionary<GridViewExportFormat, GridViewExportMethod> exportFormatsInfo;
    public static Dictionary<GridViewExportFormat, GridViewExportMethod> ExportFormatsInfo
    {
        get
        {
            if (exportFormatsInfo == null)
                exportFormatsInfo = CreateExportFormatsInfo();
            return exportFormatsInfo;
        }
    }

    static Dictionary<GridViewExportFormat, GridViewExportMethod> CreateExportFormatsInfo()
    {
        return new Dictionary<GridViewExportFormat, GridViewExportMethod> {
                { GridViewExportFormat.Pdf, GridViewExtension.ExportToPdf },
                {
                    GridViewExportFormat.Xls,
                    (settings, data) => GridViewExtension.ExportToXls(settings, data, new XlsExportOptionsEx { ExportType = DevExpress.Export.ExportType.WYSIWYG })
                },
                {
                    GridViewExportFormat.Xlsx,
                    (settings, data) => GridViewExtension.ExportToXlsx(settings, data, new XlsxExportOptionsEx { ExportType = DevExpress.Export.ExportType.WYSIWYG })
                },
                { GridViewExportFormat.Rtf, GridViewExtension.ExportToRtf },
                {
                    GridViewExportFormat.Csv,
                    (settings, data) => GridViewExtension.ExportToCsv(settings, data, new CsvExportOptionsEx { ExportType = DevExpress.Export.ExportType.WYSIWYG })
                }
            };
    }
}

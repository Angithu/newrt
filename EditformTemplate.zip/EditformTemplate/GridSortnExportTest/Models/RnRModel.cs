﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GridSortnExportTest.Models
{
    public class RnRViewModel
    {
        public Service service { get; set; }
        public PDetail details { get; set; }
        public RwkDefinition rwrk { get; set; }
    }

    public partial class Service
    {
        public int Id { get; set; }
        public string P_SERIAL_NUMBER { get; set; }
        public string P_PROGRAM { get; set; }
        public Nullable<decimal> K_NUMBER { get; set; }
        public string FW_VERSION { get; set; }
        public Nullable<int> APPROXIMATE_PG_COUNT { get; set; }
        public Nullable<int> TY_PG_COUNT { get; set; }
        public Nullable<int> REWORK_ID { get; set; }
        public string EVENT_DESCRIPTION { get; set; }
        public string CALL_STATUS { get; set; }
        public string REQUEST_TYPE { get; set; }
        public string UNIT_LOCATION { get; set; }
        public string RP_CATEGORY_1 { get; set; }
        public string RP_CATEGORY_2 { get; set; }
        public string RP_CATEGORY_3 { get; set; }
        public string ERROR_CODE_COMMENT { get; set; }
        public string RESOLUTION { get; set; }
        public string ERROR_CODE { get; set; }
        public virtual PDetail PDetail { get; set; }
    }

    public partial class PDetail
    {
        public PDetail()
        {
            this.Services = new HashSet<Service>();
        }

        public string P_SERIAL_NUMBER { get; set; }
        public string P_PROGRAM { get; set; }
        public string BUILD_AT_BIRTH { get; set; }
        public string BUILD_CURRENT { get; set; }
        public string MODEL { get; set; }
        public string OWNER_NAME { get; set; }
        public string CONTACT_NAME { get; set; }
        public string TEAM { get; set; }
        public string SITE { get; set; }
        public string TEST_GROUP { get; set; }
        public bool DECOMMISSIONED { get; set; }
        public System.DateTime DATETIME_CREATED { get; set; }
        public Nullable<System.DateTime> DATETIME_UPDATED { get; set; }

        public virtual ICollection<Service> Services { get; set; }
    }

    public partial class RpCategory
    {
        public int Id { get; set; }
        public string PROGRAM { get; set; }
        public string CATEGORY1 { get; set; }
        public string CATEGORY2 { get; set; }
        public string CATEGORY3 { get; set; }
    }

    public partial class RwkDefinition
    {
        public RwkDefinition()
        {
            this.RwkPartsLists = new HashSet<RwkPartsList>();
        }

        public int Id { get; set; }
        public string NAME { get; set; }
        public string DESCRIPTION { get; set; }
        public Nullable<System.DateTime> DATETIME_CREATED { get; set; }
        public string CREATED_BY { get; set; }

        public virtual ICollection<RwkPartsList> RwkPartsLists { get; set; }
    }

    public partial class RwkPartsList
    {
        public int Id { get; set; }
        public string NAME { get; set; }
        public string NOTES { get; set; }
        public Nullable<int> REWORK_DEFINITION_ID { get; set; }

        public virtual RwkDefinition ReworkDefinition { get; set; }
    }
}
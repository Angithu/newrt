﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GridSortnExportTest.Models
{
    public static class MyDatabaseProvider
    {
        const string mytablesDataContextKey = "DXmytablesDataContext";

        public static mytablesDataContext DB
        {
            get
            {
                if (HttpContext.Current.Items[mytablesDataContextKey] == null)
                    HttpContext.Current.Items[mytablesDataContextKey] = new mytablesDataContext();
                return (mytablesDataContext)HttpContext.Current.Items[mytablesDataContextKey];
            }
        }

        public static IEnumerable GetTables()
        {
            return DB.Tables.ToList();
        }

        public static IEnumerable GetTables1()
        {
            return DB.Table1s.ToList();
        }

        public static IEnumerable GetTables2()
        {
            return DB.Table2s.ToList();
        }

    }
}
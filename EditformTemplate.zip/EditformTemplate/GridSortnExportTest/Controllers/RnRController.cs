﻿using DevExpress.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GridSortnExportTest.Models;

namespace GridSortnExportTest.Controllers
{
    public class RnRController : Controller
    {
        // GET: RnR
        public ActionResult Index()
        {
            return View();
        }

        [ValidateInput(false)]
        public ActionResult GridViewMasterPartial()
        {
            return PartialView("_GridViewMasterPartial", GetRnRs());
        }

        [ValidateInput(false)]
        public ActionResult GridViewChildPartial(string reworkID)
        {
            ViewData["reworkID"] = reworkID;

            int id;
            bool suc = int.TryParse(reworkID, out id);

            if (suc)
            {
                return PartialView("_GridViewChildPartial", GetRWKlst());
            }
            else
            { return null; }
        }

        [ValidateInput(false)]
        public ActionResult VerticalGridRepairChildPartial(string serviceID)
        {
            ViewData["serviceID"] = serviceID;

            int id;
            bool suc = int.TryParse(serviceID, out id);

            if (suc)
            {
                return PartialView("_VerticalGridRepairChildPartial", GetServices(id));
            }
            else
            { return null; }
        }
        public ActionResult ComboBoxPartial(string filterParameterOfActionMethod)
        {
            ViewData["ComboList"] = GetSN(filterParameterOfActionMethod);
            return PartialView("PARTIAL_VIEW_WITH_COMBOBOX");
        }

        public ActionResult Category1PartialView(string filterParameterOfActionMethod)
        {
            ViewData["Category1list"] = GetCat1(filterParameterOfActionMethod);
            return PartialView("Category1PartialView");
        }
        

        #region TempDataCreation
        private List<RnRViewModel> GetRnRs()
        {
            List<RnRViewModel> lst = new List<RnRViewModel>();

            RnRViewModel item = new RnRViewModel();

            PDetail detail = new PDetail();
            detail.BUILD_AT_BIRTH = "Loc-1";
            detail.BUILD_CURRENT = "Loc-1";
            detail.CONTACT_NAME = "Conatct-1";
            detail.DATETIME_CREATED = DateTime.Now.AddDays(-30);
            detail.DATETIME_UPDATED = DateTime.Now.AddDays(-15);
            detail.DECOMMISSIONED = false;
            detail.MODEL = "Model-1";
            detail.OWNER_NAME = "Contact-1";
            detail.P_PROGRAM = "Prog-1";
            detail.P_SERIAL_NUMBER = "SerialNum-123";
            detail.SITE = "Site-1";
            detail.TEAM = "Team-1";
            detail.TEST_GROUP = "Tst_Grp-1";

            Service serviceitem = new Service();
            serviceitem.APPROXIMATE_PG_COUNT = 20;
            serviceitem.ERROR_CODE = "Code-1";
            serviceitem.ERROR_CODE_COMMENT = "Comments";
            serviceitem.EVENT_DESCRIPTION = "Event Desc";
            serviceitem.FW_VERSION = "FW-1";
            serviceitem.Id = 1;
            serviceitem.K_NUMBER = 34567;
            serviceitem.PDetail = detail;
            serviceitem.P_PROGRAM = "Prog-1";
            serviceitem.P_SERIAL_NUMBER = "SerialNum-123";
            serviceitem.REWORK_ID = 1;
            serviceitem.RP_CATEGORY_1 = "Cat-1";
            serviceitem.RP_CATEGORY_2 = "Cat-2";
            serviceitem.RP_CATEGORY_3 = "Cat-3";
            serviceitem.CALL_STATUS = "Event-1";
            serviceitem.REQUEST_TYPE = "REWORK";
            serviceitem.RESOLUTION = "Fixed";
            serviceitem.TY_PG_COUNT = 23;
            serviceitem.UNIT_LOCATION = "Loc-1";

            RwkDefinition rwkdef = new RwkDefinition();
            rwkdef.Id = 1;
            rwkdef.NAME = "rwk-1";
            rwkdef.DESCRIPTION = "Desk-1";
            rwkdef.CREATED_BY = "Cont-1";
            rwkdef.DATETIME_CREATED = DateTime.Now.AddDays(-30);

            item.details = detail;
            item.rwrk = rwkdef;
            item.service = serviceitem;

            lst.Add(item);


            RnRViewModel item1 = new RnRViewModel();

            PDetail detail1 = new PDetail();
            detail1.BUILD_AT_BIRTH = "Loc-2";
            detail1.BUILD_CURRENT = "Loc-2";
            detail1.CONTACT_NAME = "Conatct-2";
            detail1.DATETIME_CREATED = DateTime.Now.AddDays(-30);
            detail1.DATETIME_UPDATED = DateTime.Now.AddDays(-15);
            detail1.DECOMMISSIONED = false;
            detail1.MODEL = "Model-2";
            detail1.OWNER_NAME = "Contact-2";
            detail1.P_PROGRAM = "Prog-2";
            detail1.P_SERIAL_NUMBER = "SerialNum-123";
            detail1.SITE = "Site-2";
            detail1.TEAM = "Team-2";
            detail1.TEST_GROUP = "Tst_Grp-2";

            Service serviceitem1 = new Service();
            serviceitem1.APPROXIMATE_PG_COUNT = 20;
            serviceitem1.ERROR_CODE = "Code-2";
            serviceitem1.ERROR_CODE_COMMENT = "Comments";
            serviceitem1.EVENT_DESCRIPTION = "Event Desc";
            serviceitem1.FW_VERSION = "FW-2";
            serviceitem1.Id = 2;
            serviceitem1.K_NUMBER = 34567;
            serviceitem1.PDetail = detail;
            serviceitem1.P_PROGRAM = "Prog-2";
            serviceitem1.P_SERIAL_NUMBER = "SerialNum-123";
            serviceitem1.REWORK_ID = 2;
            serviceitem1.RP_CATEGORY_1 = "Cat-1";
            serviceitem1.RP_CATEGORY_2 = "Cat-2";
            serviceitem1.RP_CATEGORY_3 = "Cat-3";
            serviceitem1.CALL_STATUS = "Event-2";
            serviceitem1.REQUEST_TYPE = "REPAIR";
            serviceitem1.RESOLUTION = "Fixed";
            serviceitem1.TY_PG_COUNT = 23;
            serviceitem1.UNIT_LOCATION = "Loc-2";

            RwkDefinition rwkdef1 = new RwkDefinition();
            rwkdef1.Id = 2;
            rwkdef1.NAME = "rwk-2";
            rwkdef1.DESCRIPTION = "Desk-2";
            rwkdef1.CREATED_BY = "Cont-2";
            rwkdef1.DATETIME_CREATED = DateTime.Now.AddDays(-30);

            item1.details = detail1;
            item1.rwrk = rwkdef1;
            item1.service = serviceitem1;

            lst.Add(item1);

            return lst;
        }

        private List<RwkDefinition> GetRWKlst()
        {
            List<RwkDefinition> lst = new List<RwkDefinition>();

            RwkDefinition rwkdef1 = new RwkDefinition();
            rwkdef1.Id = 1;
            rwkdef1.NAME = "rwk-1";
            rwkdef1.DESCRIPTION = "Desk-1";
            rwkdef1.CREATED_BY = "Cont-1";
            rwkdef1.DATETIME_CREATED = DateTime.Now.AddDays(-30);

            RwkDefinition rwkdef2 = new RwkDefinition();
            rwkdef2.Id = 2;
            rwkdef2.NAME = "rwk-2";
            rwkdef2.DESCRIPTION = "Desk-2";
            rwkdef2.CREATED_BY = "Cont-2";
            rwkdef2.DATETIME_CREATED = DateTime.Now.AddDays(-30);

            lst.Add(rwkdef1);
            lst.Add(rwkdef2);

            return lst;
        }

        private List<Service> GetServices(int id)
        {
            List<Service> lst = new List<Service>();

            PDetail detail = new PDetail();
            detail.BUILD_AT_BIRTH = "Loc-1";
            detail.BUILD_CURRENT = "Loc-1";
            detail.CONTACT_NAME = "Conatct-1";
            detail.DATETIME_CREATED = DateTime.Now.AddDays(-30);
            detail.DATETIME_UPDATED = DateTime.Now.AddDays(-15);
            detail.DECOMMISSIONED = false;
            detail.MODEL = "Model-1";
            detail.OWNER_NAME = "Contact-1";
            detail.P_PROGRAM = "Prog-1";
            detail.P_SERIAL_NUMBER = "SerialNum-123";
            detail.SITE = "Site-1";
            detail.TEAM = "Team-1";
            detail.TEST_GROUP = "Tst_Grp-1";

            Service serviceitem = new Service();
            serviceitem.APPROXIMATE_PG_COUNT = 20;
            serviceitem.ERROR_CODE = "Code-1";
            serviceitem.ERROR_CODE_COMMENT = "Comments";
            serviceitem.EVENT_DESCRIPTION = "Event Desc";
            serviceitem.FW_VERSION = "FW-1";
            serviceitem.Id = 1;
            serviceitem.K_NUMBER = 34567;
            serviceitem.PDetail = detail;
            serviceitem.P_PROGRAM = "Prog-1";
            serviceitem.P_SERIAL_NUMBER = "SerialNum-123";
            serviceitem.REWORK_ID = 1;
            serviceitem.RP_CATEGORY_1 = "Cat-1";
            serviceitem.RP_CATEGORY_2 = "Cat-2";
            serviceitem.RP_CATEGORY_3 = "Cat-3";
            serviceitem.CALL_STATUS = "Event-1";
            serviceitem.REQUEST_TYPE = "REWORK";
            serviceitem.RESOLUTION = "Fixed";
            serviceitem.TY_PG_COUNT = 23;
            serviceitem.UNIT_LOCATION = "Loc-1";

            lst.Add(serviceitem);

            PDetail detail1 = new PDetail();
            detail1.BUILD_AT_BIRTH = "Loc-2";
            detail1.BUILD_CURRENT = "Loc-2";
            detail1.CONTACT_NAME = "Conatct-2";
            detail1.DATETIME_CREATED = DateTime.Now.AddDays(-30);
            detail1.DATETIME_UPDATED = DateTime.Now.AddDays(-15);
            detail1.DECOMMISSIONED = false;
            detail1.MODEL = "Model-2";
            detail1.OWNER_NAME = "Contact-2";
            detail1.P_PROGRAM = "Prog-2";
            detail1.P_SERIAL_NUMBER = "SerialNum-321";
            detail1.SITE = "Site-2";
            detail1.TEAM = "Team-2";
            detail1.TEST_GROUP = "Tst_Grp-2";

            Service serviceitem1 = new Service();
            serviceitem1.APPROXIMATE_PG_COUNT = 20;
            serviceitem1.ERROR_CODE = "Code-2";
            serviceitem1.ERROR_CODE_COMMENT = "Comments";
            serviceitem1.EVENT_DESCRIPTION = "Event Desc";
            serviceitem1.FW_VERSION = "FW-2";
            serviceitem1.Id = 2;
            serviceitem1.K_NUMBER = 34567;
            serviceitem1.PDetail = detail;
            serviceitem1.P_PROGRAM = "Prog-2";
            serviceitem1.P_SERIAL_NUMBER = "SerialNum-321";
            serviceitem1.REWORK_ID = 2;
            serviceitem1.RP_CATEGORY_1 = "Cat-1";
            serviceitem1.RP_CATEGORY_2 = "Cat-2";
            serviceitem1.RP_CATEGORY_3 = "Cat-3";
            serviceitem1.CALL_STATUS = "Event-2";
            serviceitem1.REQUEST_TYPE = "REPAIR";
            serviceitem1.RESOLUTION = "Fixed";
            serviceitem1.TY_PG_COUNT = 23;
            serviceitem1.UNIT_LOCATION = "Loc-2";

            lst.Add(serviceitem1);

            if (id != 0)
                return lst.Where(r => r.Id == id).ToList();
            else
                return lst;


        }

        public static List<string> GetPrograms()
        {
            List<string> lst = new List<string>();

            lst.Add("Prog-1");
            lst.Add("Prog-2");
            lst.Add("Prog-2");
            lst.Add("Prog-3");
            lst.Add("Prog-4");
            lst.Add("Prog-5");

            return lst;
        }

        public static List<string> GetRequestTypes()
        {
            List<string> lst = new List<string>();

            lst.Add("REWORK");
            lst.Add("REPAIR");
            lst.Add("INSPECTION");
            lst.Add("Others");

            return lst;
        }

        public static List<string> GetSN(string prog)
        {
            List<string> lst = new List<string>();

            if (prog == "Prog-1")
            {
                lst.Add("SerialNum-123");
                lst.Add("SerialNum-321");
                lst.Add("SerialNum-421");
                lst.Add("SerialNum-721");
            }
            else
            {
                lst.Add("SerialNum-723");
                lst.Add("SerialNum-821");
                lst.Add("SerialNum-921");
                lst.Add("SerialNum-521");
            }

            return lst;
        }

        public static List<string> GetCat1(string prog)
        {
            List<string> lst = new List<string>();

            if (prog == "Prog-1")
            {
                lst.Add("Cat-1");
                lst.Add("Cat-2");
            }
            else
            {
                lst.Add("Cat-3");
                lst.Add("Cat-4");
            }

            return lst;
        }

        #endregion
    }
}
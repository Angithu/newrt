﻿using DevExpress.Web;
using DevExpress.Web.Mvc;
using GridSortnExportTest.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GridwithhrefSample.Models
{
    public class DataViewsController : Controller
    {
        // GET: DataViews
        public ActionResult TableViews()
        {
            ViewBag.ViewsLst = GetViews();
            return View();
        }

        public ActionResult gvPartial(string ddlViews = "Table")
        {
            //How to Bind Data Dynamically with dynamic colums using ServerMode/LINQtoSQL/LINQtoEF to GridView ?
            ViewData["ddlViews"] = ddlViews;
            string ddlViewscheck = ComboBoxExtension.GetValue<string>("ddlViews");

            if (ddlViews == "Table1")
                return PartialView("gvPartial", MyDatabaseProvider.DB.Table1s);
            else if (ddlViews == "Table2")
                return PartialView("gvPartial", MyDatabaseProvider.DB.Table2s);
            else
                return PartialView("gvPartial", MyDatabaseProvider.DB.Tables);

            //How to Handle in gvPartial
        }

        private List<string> GetViews()
        {
            List<string> lst = new List<string>();

            lst.Add("Table");
            lst.Add("Table1");
            lst.Add("Table2");
            return lst;
        }

        public ActionResult ExportTo(string exportFormat = "xls", string ddlDataViews = "Table")
        {
            string ddlViews = ComboBoxExtension.GetValue<string>("ddlViews");
            GridViewExportFormat format = GetExportFormat();
            IEnumerable table;

            switch (ddlDataViews)
            {
                case "Table2":
                    table = MyDatabaseProvider.DB.Table2s;
                    break;
                case "Table1":
                    table = MyDatabaseProvider.DB.Table1s;
                    break;
                default:
                    table = MyDatabaseProvider.DB.Tables;
                    break;
            }

            return GridViewExportHelper.ExportFormatsInfo[format](GetDataViewsGridSettings(), table);
        }

        protected GridViewExportFormat GetExportFormat()
        {
            var result = GridViewExportFormat.None;
            Enum.TryParse(Request.Params["ExportFormat"], out result);
            return result;
        }


        public static GridViewSettings GetDataViewsGridSettings()
        {
            var settings = new GridViewSettings();

            settings.Name = "GridView";
            settings.KeyFieldName = "Id";

            settings.Settings.ShowFilterBar = GridViewStatusBarMode.Visible;

            settings.SettingsFilterControl.ViewMode = FilterControlViewMode.Visual;
            settings.SettingsFilterControl.AllowHierarchicalColumns = true;
            settings.SettingsFilterControl.ShowAllDataSourceColumns = false;
            settings.SettingsFilterControl.MaxHierarchyDepth = 1;

            settings.CallbackRouteValues = new { Action = "gvPartial", Controller = "DataViews" };

            settings.ClientSideEvents.BeginCallback = "onBeginCallback";

            settings.DataBound += (s, e) => {
                MVCxGridView grid = (MVCxGridView)s;
                grid.DataColumns["Product"].SettingsHeaderFilter.Mode = GridHeaderFilterMode.CheckedList;
            };

            settings.BeforeGetCallbackResult += (s, e) => {
                MVCxGridView grid = (MVCxGridView)s;
                if (grid.DataColumns.FirstOrDefault(c => c.FieldName == "Units") == null)
                    grid.AutoFilterByColumn(new GridViewDataColumn { FieldName = "Units" }, "");
            };

            settings.Settings.ShowHeaderFilterButton = true;

            settings.CustomJSProperties = (s, e) =>
            {
                ASPxGridView grid = (ASPxGridView)s;
                e.Properties["cpDataViewsFilterExpression"] = grid.FilterExpression;
            };

            return settings;
        }

    }
}